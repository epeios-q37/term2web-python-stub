name = "term2web"

from .term2web import *